from tkinter import *

root = Tk(className = "border")
root.geometry("900x500")

str1 = StringVar()
str1.set("Test")

str2 = StringVar()
str2.set("test\nstring\nabc\nbcd\nefg\nhij\njkl")

l1 = Label(root, textvariable = str1, 
				fg = "white", bg = "black",
				font = ("Times",10),
				bd = 20,
				width = 50,
				
			).pack()

l2 = Label(root, textvariable = str2,
			fg= "red", bg = "yellow",
			font = ("arial",15),
			bd = 25,
			width = 60,
			
			).pack()
root.mainloop()