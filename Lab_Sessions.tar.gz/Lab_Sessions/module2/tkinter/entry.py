from tkinter import *

root = Tk(className = "Entry")
root.geometry("300x300")

fr_name = Frame(root).pack()

lb_heading = Label(fr_name, text = "Details", font = ("bold")).pack()
lb_name = Label(fr_name, text = "Enter your name").pack()
en_name = Entry(fr_name).pack()

root.mainloop()