from tkinter import *
root_obj = Tk(className = "test")

root_obj.geometry("500x700")
root_obj.mainloop()