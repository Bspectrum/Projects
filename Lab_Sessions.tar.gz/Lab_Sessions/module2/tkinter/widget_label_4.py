from tkinter import *

root= Tk(className="label4")
root.geometry("200x200")

name_label = Label(root, text = "Kishor",
						fg = "white", bg = "red")
name_label.pack()

root.mainloop()
