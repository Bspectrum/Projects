from tkinter import *

root = Tk(className = "checkbox")
root.geometry("200x200")

c1 =  Checkbutton(root, text ="checkbox 1", onvalue = 1, offvalue=0,
					height=5).pack()

root.mainloop()