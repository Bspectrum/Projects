from Tkinter import *
import tkMessageBox

root = Tk()
t1 = MessageBox.showinfo("Title","Message").pack()
root.mainloop()
