from tkinter import *

root = Tk(className="label widget")
root.geometry("500x500")

str_name = input("Enter a name")
name_label = Label(root, text = str_name ,
						fg = "white" , bg = "red" , 
						font = ('',40),
												
						)
name_label.pack()

root.mainloop()