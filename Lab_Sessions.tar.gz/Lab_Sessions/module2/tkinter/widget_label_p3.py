from tkinter import *
root_obj = Tk(className="Widget_label1")
name_label = Label(root_obj,text="Kishor")
name_label.pack()
root_obj.geometry("200x200")
root_obj.mainloop()