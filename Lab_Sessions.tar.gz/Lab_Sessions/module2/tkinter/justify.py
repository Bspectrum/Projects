from tkinter import *

root = Tk(className = "justify")
root.geometry("1000x800")

str1 = StringVar()
str1.set("Test")

str2 = StringVar()
str2.set("test12131\nstring_statements\nabc_alphabets\nbcd_abc\nefg_12\nhij_22\njkl")

# l1 = Label(root, textvariable = str1, 
# 				fg = "white", bg = "black",
# 				font = ("Times",10),
# 				bd = 40,
# 				width = 100,
# 				anchor = NW
# 			).pack()

l2 = Label(root, textvariable = str2,
			fg= "black", bg = "yellow",
			font = ("arial",20),
			bd = 25,
			width = 50,
			# anchor = NE
			justify = LEFT
			).pack()


l3 = Label(root, textvariable = str2,
			fg= "white", bg = "black",
			font = ("arial",12),
			bd = 25,
			width = 50,
			# anchor = NE
			justify = RIGHT
			).pack()

l4 = Label(root, textvariable = str2,
			fg= "white", bg = "green",
			font = ("arial",16),
			bd = 30,
			width = 50,
			# anchor = NE
			justify = CENTER
			).pack()
root.mainloop()