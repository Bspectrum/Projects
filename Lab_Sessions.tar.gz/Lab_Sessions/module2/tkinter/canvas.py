from tkinter import *

root = Tk(className = "canvas")
root.geometry("250x250")

c1 = Canvas(root, bd =5 , bg ="red" , confine=TRUE, cursor = "dot",
	height = 200, width=200).pack()
root.mainloop()