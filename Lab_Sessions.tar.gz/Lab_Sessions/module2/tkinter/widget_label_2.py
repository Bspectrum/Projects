from tkinter import *

root = Tk(className = "Label_fg")
root.geometry("200x200")

label1 = Label(root, text = "Kishor",
					fg="red")
label1.pack()

root.mainloop()