from tkinter import *

root = Tk(className = "Message1")
root.geometry("500x300")

message_string = StringVar()
message_string.set("This widget can be used to display short text messages.Aspect ratio, given as the width/height relation in percent. The default is 150, which means that the message will be 50 wider than it is high.This widget can be used to display short text messages")

m1 = Message(root, textvariable = message_string,
					font = ("Times",20),
					fg = "red", bg = "yellow",
					bd=4
					).pack()

root.mainloop()