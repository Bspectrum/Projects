from tkinter import *

root = Tk(className="Photoimage")
root.geometry("300x200")



image_var = PhotoImage(file = "duck.png")
l1 = Label(root, image=image_var, relief = SUNKEN, bd = 5).pack()

root.mainloop()