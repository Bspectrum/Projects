from tkinter import *
root = Tk(className = "List 1")
root.geometry("200x200")


lb = Listbox(root, selectmode = EXTENDED)
item_list = ["one","two","three","four","python","django","perl","one","two","three","four","python","django","perl"]
for i in item_list:
	lb.insert(END,i)
lb.yview()
lb.pack()
def lb_delete():

	lb.delete(lb.curselection())
	# sel_index_list = list(lb.curselection())
	# return sel_index_list[0],sel_index_list[sel_index_list.len()-1]

del_b = Button(root, text = "click to delete" ,
				command = lb_delete).pack()

# l1.delete(0)


root.mainloop()