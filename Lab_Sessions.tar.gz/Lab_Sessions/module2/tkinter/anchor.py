from tkinter import *

root = Tk(className = "anchor")
root.geometry("600x600")

str1 = StringVar()
str1.set("Test")

str2 = StringVar()
str2.set("test\nstring\nabc\nbcd\nefg\nhij\njkl")

l1 = Label(root, textvariable = str1, 
				fg = "white", bg = "black",
				font = ("Times",10),
				bd = 40,
				width = 100,
				anchor = NW
			).pack()

l2 = Label(root, textvariable = str2,
			fg= "red", bg = "yellow",
			font = ("arial",20),
			bd = 40,
			width = 100,
			anchor = NE
			).pack()
root.mainloop()