from tkinter import *
master = Tk(className = "button_click1")
master.geometry("200x300")

def printval():
	print("hi")

b1 = Button(master,text = "click me", command = printval).pack()


master.mainloop()
