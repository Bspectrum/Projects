from tkinter import *
root = Tk(className = "border_styles")
root.geometry("400x400")

#str_value = StringVar()
#str_value.set("This is a string..\nA newline\nThis is another sentence")

l1 = Label(root, text = "This is a test string- raised",
				relief = RAISED , 
				font = ("Arial", 20,"bold")).pack()

l2 = Label(root, text = "This is a test string - ridge",
				relief = RIDGE, 
				font = ("Arial", 20,"underline")).pack()

l3 = Label(root, text = "This is a test string -flat",
				relief = FLAT , 
				font = ("Times", 20,"bold")).pack()

l4 = Label(root, text = "This is a test string -groove",
				relief = GROOVE, 
				font = ("Times", 20)).pack()

l5 = Label(root, text = "This is a test string - solid",
				relief = SOLID, 
				font = ("Times", 20)).pack()

l6 = Label(root, text = "This is a test string - sunken",
				relief = SUNKEN, 
				font = ("Times", 20)).pack()


root.mainloop()