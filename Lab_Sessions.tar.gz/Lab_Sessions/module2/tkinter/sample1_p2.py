from Tkinter import *

obj = Tk(className = "first gui program python2")

obj.mainloop()