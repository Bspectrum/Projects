import re
#Write a Python program that matches a string that has an 'a' 
#followed by anything, ending in 'b'

def check_pattern(chk_str):
	pattern='^a+\w|\W+b$'
	print("Checks whether given string starts with 'a' and ends with 'b'...")
	print(chk_str)
	if re.match(pattern,chk_str):
		print("Matches the given pattern")
	else:
		print("Does not match the given pattern")


ui_str=input("Ente a string:")
check_pattern(ui_str)