#search a substring using regex

import re
s_str=input("Enter a string:")
sub_str=input("Enter a substring to search:")
print(re.findall(sub_str,s_str,re.IGNORECASE))

