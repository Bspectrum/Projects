#read particular values from file with match a given pattern
import re

f_obj=open("name_list.txt","r")

for i in f_obj:
	#print(i)
	#print("inside for loop")
	if re.match(r"K.*Mathew",i):
		print(i)
	
f_obj.close()
