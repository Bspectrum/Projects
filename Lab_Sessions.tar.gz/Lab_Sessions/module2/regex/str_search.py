#read a string which contains only lowercase and or numbers using regex

import re

s_str=input("Enter string")

if re.match(r"[/t]",s_str):
	print("yes")
else:
	print("no")
