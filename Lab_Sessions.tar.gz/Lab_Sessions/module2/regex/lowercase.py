import re
#Write a Python program to find sequences of lowercase letters joined with  an underscore.
def check_pattern(chk_str):
	pattern='_+[a-z]+_$'
	if re.search(pattern,chk_str):
		print("Found")
	else:
		print("Not Found")

ui_str=input("Ente a string:")
check_pattern(ui_str)