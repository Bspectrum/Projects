from tkinter import *

root = Tk(className="My first GUI") #root contain all widgets

root.mainloop()  #to keep running
