from tkinter import *

root = Tk(className="Message Widget")

root.geometry("500x500")

my_label = Label(root, text="Some long text here")
my_label.pack()

my_msg = Message(root, text="Some long text here",width=50)
my_msg.pack()

root.mainloop()

