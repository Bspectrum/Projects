def yrange(n):
    i = 0
    while i < n:
        yield i
        i += 1

def jrange(n):
    for j in range(0,n):
        yield j


#print(yrange(5))

#y = yrange(5)

#print(y.__next__())
#print(y.__next__())
#print(y.__next__())
#print(y.__next__())
#print(y.__next__())
#print(y.__next__())
#print(y.__next__())

z = jrange(5)

print(z.__next__())
print(z.__next__())
print(z.__next__())
print(z.__next__())
print(z.__next__())
print(z.__next__())
print(z.__next__())


