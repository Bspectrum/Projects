class Person:
    # Define the class parameter "name"
    name = "Person"
    
    def __init__(self, name = "Test"):
        # self.name is the instance parameter
        self.name = name

jeffrey_obj = Person("Jeffrey")
print("@@@@@@@@@@@@@@@",Person.name, jeffrey_obj.name)

nico_obj = Person()
nico_obj.name = "Nico"
print("*************",Person.name, nico_obj.name)
