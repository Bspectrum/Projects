a=int(input("enter the first num:"))
b = int(input("enter the second number:"))

try:	
	st = Student.objects.get(name='nissy')
except Exception:
	st = None
if st!= None:
 	hjshdfs

else:
    bldfjglkjfgkldfg

