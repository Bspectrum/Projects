
try:
    calc = 5/0
except ZeroDivisionError as e:
    print(e)
#except Exception, err:
    #print 'Caught an exception'
#finally:
    #print 'In finally block for cleanup'
