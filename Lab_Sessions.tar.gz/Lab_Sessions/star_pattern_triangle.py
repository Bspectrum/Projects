limit = int(input("enter the limit :"))

k = 2*limit - 2

for i in range(0,limit):
	for j in range(0,k):
		print(end=" ")
	k = k-1
	for j in range(0,i+1):
		print('*',end=" ")
	print("\r")



for m in range(1,limit):
	for n in range(0,i+1):
		print("*",end=" ")
	print()

	#For printing the lower part of pyramid
# for m in range(limit,0):
# 	for n in range(i,0,-1):
# 		print("*", end=" ")
# 	print()