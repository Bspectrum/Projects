#Define a class named BankAccount. This class should contain methods withdraw() and deposit to calculate the balance amount remained in your account.

class BankAccount:
	bal=0.0
	def __init__(self):
		self.bal=0.0		
		print("Current Balance: %f" %(self.bal))
		
		
	def withdraw(self,amt):
		self.bal-=amt
		print("Withdrawal amount: %f" %(amt))
		print("Balance: %f" %(self.bal))
		#return self.bal
		
	def deposit(self,amt):
		self.bal+=amt
		print("Deposit amount: %f" %(amt))
		print("Balance: %f" %(self.bal))
		#return self.bal
		
b1=BankAccount()
amt=float(input("Enter amount to deposit:"))

b1.deposit(amt)
amt=float(input("Enter amount to withdraw:"))

b1.withdraw(amt)
		

