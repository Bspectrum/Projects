#multiple inheritance

class base1:
	b1_val1=12
	b1_val2=14
	
class base2:
	b2_val1=35
	b2_val2=38
	

class der_class(base1,base2):
	def __init__(self):
		print("In Derrived class")
		
		
	
	def printval(self):
		print("from base1:")
		print(self.b1_val1)
		print(self.b1_val2)

		print("from base class 2:")
		print(self.b2_val1)
		print(self.b2_val2)


d1=der_class()
d1.printval()

#d1.printval()
