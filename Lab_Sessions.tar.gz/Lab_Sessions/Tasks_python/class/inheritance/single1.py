#single inheritance

class base1:
	b_val1=10
	b_val2=20
	
	def __init__(self):
		print("From base class constructor")
		
		
class der1(base1):
	der_val1=15
	
	def __init__(self):
		print("From derrived class constructor")
		print("der_val1=",self.der_val1)
		print("b_val1=",self.b_val1)
		print("b_val2=",self.b_val2)
		

ob1=der1()

ob2=base1()
