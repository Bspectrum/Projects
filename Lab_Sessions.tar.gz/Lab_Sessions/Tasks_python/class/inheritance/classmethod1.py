class Foo:
	@classmethod
	def clshello(cls):
		print("class method hello from %s" % cls.__name__)
		
	@staticmethod
	def stathello():
		print("static method hello from stat hello")
		

Foo.clshello()

Foo().stathello()

