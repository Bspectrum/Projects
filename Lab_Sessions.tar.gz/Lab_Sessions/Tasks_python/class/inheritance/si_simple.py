class A:
	val1=2
class B(A):
	val2=5
	
	
b=B()
print(b.val1,b.val2,end=',')
