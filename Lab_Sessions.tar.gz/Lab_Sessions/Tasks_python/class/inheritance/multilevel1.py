#multi-level inheritance

class A:
	a_val1=52
	a_val2=59
	pass
#	def __init__(self):
#		print("From class A")
#	
#	def disp(self):
#		print("class A constructor")
#		print(self.a_val1)
#		print(self.a_val2)
	
class B(A):
	b_val1=62
	b_val2=67
	pass
#	def __init__(self):
#		print("class B constructor")
#	
#	def disp(self):
#		print("From B")
#		print(self.b_val1)
#		print(self.b_val2)


class C(B):
	c_val1=821
	c_val2=892
	def __init__(self):
		print(" class C Constructor")
	
	def disp(self):
		print("From C")
		print(self.c_val1)
		print(self.c_val2)
		
		print("From A")
		print(self.a_val1)
		print(self.a_val2)

		print("From B")
		print(self.b_val1)
		print(self.b_val2)
		
ob1=C()
ob1.disp()
	



	


