#method overloading

class Student:
	#def __init__(self):
		#name=''
		#age='0'
		#grade=''

	def s_read(self,name=None):
		#self.name=name
		if name is not None:
			print("hi")
		else:
			print("hello")
		
	#def s_read(self,name=None,age=None):
		#print("Method 2  Name, age")
		
	#def s_read(self,name,age,grade):
		#self.name=name
		#self.age=age	
		#self.grade=grade
		#print("Method 3 Name age grade")


s1 = Student()

s1.s_read()
print("__________________")
s1.s_read('ajai')
