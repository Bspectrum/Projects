#method overloading

class Student:
	#def __init__(self):
		#name=''
		#age='0'
		#grade=''


	def s_read(self,age=18,score=20):
		#self.name=name
		print("Method 1 , age, score")
	#	if name is not None:
	#		print("hi")
	##		print("hello")
	#	
	def s_read(self,name='name',grade='A'):
		print("Method 2  Name,grade")
		

#s1 = Student()

#s1.s_read(24,30)

s2 = Student()
s2.s_read('Vishnu','C')
