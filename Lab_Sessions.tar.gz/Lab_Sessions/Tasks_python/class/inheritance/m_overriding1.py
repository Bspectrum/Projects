#implementation of method overriding using simple inheritance

class A:
	def __init__(self):
		print("Text in constructor class A(Base class)")

	def display(self):
		print("In first class: inside display function")
		
		
		
class B(A):
	def __init__(self):
		print("Text in class B constructor (Derrived class)")
		super().__init__()
		

	def display(self):
		super().display()
		print("In second class: inside display function")

ob1=B()
ob1.display()




