str1='name of the person'

print(str1.title())
