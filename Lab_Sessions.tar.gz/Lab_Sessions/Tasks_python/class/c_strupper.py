#Define a class which has at least two methods one, to get a string from console  input and other is to print the string in uppercase.

class Student:
	c_str=" "
	
	def read(self):
		self.c_str=input("Enter string:")
	
	def display(self):
		print(self.c_str.upper())
		
		
s1=Student()

s1.read()
s1.display()
		


