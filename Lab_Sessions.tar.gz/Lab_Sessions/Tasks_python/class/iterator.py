# 1,5

class printnum:
	def __init__(self,max):
		self.i=1
		self.max=max
		
	def __iter__(self):
		return self
		
	def __next__(self):
		if self.i>self.max:
			raise StopIteration		
		else:
			val= self.i
			self.i += 1
			return val	
	
	
ob1= printnum(5)
for i in ob1:
	print(i)
#print(ob1.i)

#for i in printnum(5):
	#print(i)
