#Define a class, which have a class parameter and have a same instance parameter.

class Test:
	sample=10
	
	def display(self):
		x = 10
		print(Test.sample)
		# print(sample)
		print("TTTTTTTTTTTTT",x)
		# sample=20
		# print("Class parameter :",self.sample)
		# print("Instance parameter:",sample)


t1=Test()
t1.display()

print(t1.sample)
print(Test.sample)
print(t1.x)
