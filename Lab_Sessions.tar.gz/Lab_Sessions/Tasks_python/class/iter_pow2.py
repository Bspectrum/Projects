#power of 2 using iterator implementing class

class Pow2:
	def __init__(self,max=0):
		self.max=max
		
	def __iter__(self):
		self.n=0
		return self
	
	def __next__(self):
		if self.n>=self.max:
			raise StopIteration
		else:
			res= (2**self.n)
			self.n+=1
			return res
			

for i in Pow2(5):
	print(i)
		
	


