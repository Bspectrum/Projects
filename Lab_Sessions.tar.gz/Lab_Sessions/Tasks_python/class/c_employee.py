#employee object creation class variable value change, reg:-

class Employee:
	e_count=0  #common variable for all the objects
	
	def __init__(self,name,salary):
		self.name=name
		self.salary=salary
		Employee.e_count+=1
		
	def emp_count(self):
		print("Employee count:",Employee.e_count)
		
	def disp_emp(self):
		print("Name:",self.name)
		print("Salary:",self.salary)
	
e1=Employee('Manu',12000)
e2=Employee('Hari',15400)
e3=Employee('Vishnu',13500)

e3.emp_count()


	
