#print fibonocci series using iterator

class Fibo:
	def __init__(self,max):
		self.max=max
		
		
	def __iter__(self):
		self.i=0
		self.j=1
		return self
		
	def __next__(self):
		temp=self.i
		if self.i>self.max:
			raise StopIteration
		
		else:
			self.i=self.j
			self.j=temp+self.j
			return temp
			

ob1=Fibo(10)
			
for i in ob1:
	print(i)
