
list1=['test',21,3,75.5,'oracle','sun']

list2=['windows',8.1,2000,'Vista',1998]

print("Printing list 1")
print(list1)
print("Printing list 2")
print(list2)

print("Concatenation")
print(list1+list2)

print("Slicing")
print(list1[0:2])
print(list2[2:4])

print("Repeating")

print(list1*2)
print(list2*3)

print("Indexing")

print(list1[2])
print(list1[1:4])

print(list2[4:])
print(list2[1:4])
