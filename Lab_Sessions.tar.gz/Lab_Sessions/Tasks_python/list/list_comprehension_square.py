#using list comprehension get the squares of an interval of integers

n=int(input("Enter number of elements:"))

n_list=[]

print("Enter values into the list:")
for i in range(0,n):
	l_val=int(input(""))
	n_list.append(l_val)


sq_list=[i**2 for i in n_list]

print(sq_list)
