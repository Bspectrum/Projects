#enumerate

v_list=['Suzuki','Honda','Maruti','Volkswagon']

for i in enumerate(v_list):
	print(i)


print("----------------------------")


for i,val in enumerate(v_list):
	print(i,val)

print("_______________________________")


for i,val in enumerate(v_list,start=100):
	print(i,val)
print("_______________________________")


for i,val in enumerate(v_list,10):
	print(i,val)
