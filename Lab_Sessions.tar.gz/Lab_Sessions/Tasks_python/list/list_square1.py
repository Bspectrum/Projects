#read elements into a list, insert squares of the elements into another list

list1=[]
list2=[]

n1=int(input("Enter the number of elements:"))
print("Enter elements")

for i in range(0,n1):
	listval=int(input(""))
	list1.append(listval)

for i in list1:
	sqval=(i**2)
	list2.append(sqval)

print(list2)
