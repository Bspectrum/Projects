#program to print the squares of numbers in an interval into a list

ll=int(input("Enter lower limit:"))
ul=int(input("Enter upper limit:"))
sqlist=[]
for i in range(ll,(ul+1)):
	sqlist.append(i**2)

print(sqlist)
