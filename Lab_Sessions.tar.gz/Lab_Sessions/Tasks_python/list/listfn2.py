#list operations

list1=['Oracle','MySQL',32.14,85,'Windows',85]
list2=['test','Microsoft','IBM',25,457]

print("View list")

print(list1)
print(list2)
print("-----------------------")
print("list update")
list1[4]="Spectrum"

list2[2]="Ernakulam"

print(list1)
print(list2)
print("-----------------------")
print("Slicing")
print(list1[2:4])
print(list2[2:5])
print("-----------------------")
print("Access specified location")
print(list1[2])
print(list2[4])
print("-----------------------")
