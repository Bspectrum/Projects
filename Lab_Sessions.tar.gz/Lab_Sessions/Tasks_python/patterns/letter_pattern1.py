#print pattern
#A
#BC
#DEF
#GHIJ

l_code=65

for i in range(1,5):
	for j in range(0,i):
		print(chr(l_code),end=" ")
		l_code+=1
	print("\n")

