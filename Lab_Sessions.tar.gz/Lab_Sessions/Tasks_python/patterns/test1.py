for k in range(0,5):			
	for l in range(0,k+1):				
		print((2**l),end=" ")	
	print("\n")
		#for m in range(0,k):
