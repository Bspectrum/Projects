import calendar

print(calendar.month(2017,10))

c=calendar.TextCalendar(calendar.SUNDAY)
str1=c.formatmonth(2017,10)

print(str1)

#for c in c.itermonthdays(2017,10):
#	print(c,end=" ")


#for i in calendar.month_name:
#	print(i,end=" ")

print(calendar.month_name[5])

for i in calendar.day_name:
	print(i)

c= calendar.TextCalendar(calendar.SUNDAY)
str1= c.formatmonth(2017,10)
print(str1)


for i in calendar.month_abbr:
	print(i)


for i in calendar.day_abbr:
	print(i)


