def show(str1):
	print("SSSSSSSSSSSSSSSSS",str1)


def display(a,b):
	return(a+b)
