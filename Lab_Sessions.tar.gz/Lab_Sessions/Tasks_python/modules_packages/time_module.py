import time


print(time.time())
now = time.localtime(time.time())
print(time.localtime(time.time()))

print("asctime",time.asctime(now))
print("strftime",time.strftime("%y/%m/%d %H:%M",now))

print("strftime",time.strftime("%a %b %d",now))  


print(time.strftime("%c", now))      


print("UUUUUU", time.strftime("%Y-%m-%d %H:%M:%S %Z", now))

