import time


# t= (2009, 2, 17, 17, 3, 38, 1, 48, 0)
# secs = time.mktime( t )
# print(secs)

str1  = ('01','12','00')
print(time.strftime(str1, "%H:%M:%S"))