from math import sqrt, factorial, pi, ceil, floor, copysign, fabs, fmod, fsum, exp






#x=int(input("Enter a value"))

print(sqrt(25))

print(factorial(3))

print(pi)

print(ceil(2.5))

print(floor(2.7))

print(copysign(2,-8))
print(fabs(-28.8))

print(fmod(18,8))


list2=[2,5]
print("%%%%%%%%%%%",sum(list2))
print(fsum(list2))

print(exp(2))
