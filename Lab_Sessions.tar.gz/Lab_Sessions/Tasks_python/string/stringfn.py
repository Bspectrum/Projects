print("string functions")

str1=input("Enter first string:")
print("String length",len(str1))
str2=input("Enter second string:")
print("String length",len(str2))
print("string concatenation")

print(str1+str2)
print("-----------------")
str3=input("enter a new string:")
print("String length",len(str3))
li=int(input("Enter lower index:"))
ui=int(input("Enter upper index:"))

print("string slicing")

str4=input("enter a new string:")
nu=int(input("Enter the number of times the entered string should repeat:"))
str4*nu

print(str3[li:ui])

