# A program to Check if the given string  is Palindrome or not

print("A program to check whether the given string is palindrome or not.")
chkstr=input("Enter a string:")
revstr=chkstr[::-1]

if chkstr==revstr:
	print("String is a palindrome.")
else:
	print("String is not a palindrome.")
	
