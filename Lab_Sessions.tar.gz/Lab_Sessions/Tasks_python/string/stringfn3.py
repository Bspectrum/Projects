mystr=input("Enter a string:")
print("The string you entered is %s" %(mystr))
print("To upper:")
print(mystr.upper())
print("-------------")

print("To lower:")
print(mystr.lower())
print("-------------")

print("Title:")
print(mystr.title())
print("-------------")

print("Capitalize:")
print(mystr.capitalize())
print("-------------")

print("swapcase:")
print(mystr.swapcase())
print("-------------")

print("Checking whether isdigit:",mystr.isdigit())

print("-------------")

print("Checking whether isalpha:",mystr.isalpha())

print("-------------")

print("Checking whether isalnum:",mystr.isalnum())

print("-------------")

findstr=input("Enter a substring to find:")
print("%s found in the string at %d" %(findstr,mystr.find(findstr)))
print("-------------")

countstr=input("Enter a substring to count the number of appearences:")
print("%s appears %d times in the string" %(countstr,mystr.find(countstr)))

print("-------------")

