str_cmpny = "Spectrum"

for index in range(0,len(str_cmpny)):
	print(str_cmpny[index])


for index in str_cmpny:
	print(index)



