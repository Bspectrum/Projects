#program to find whether given no. is Armstrong or not

#For an armstrong number, sum of the cubes of the digits is the number itself

num=int(input("Enter a number:"))
nsum=0
temp=num
while(temp>0):
	r=temp%10
	nsum+=(r**3)
	temp=int(temp/10)



if nsum==num:
	print("%d is an armstrong number" %(num))
else:
	print("%d is not an armstrong number" %(num))
	

