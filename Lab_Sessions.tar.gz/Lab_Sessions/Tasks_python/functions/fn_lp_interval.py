#To display leap years in a given interval
def leapyear(ll,ul):
	"To calculate leap years in a given interval"
	y_lp=[]
	for i in range(ll,ul+1):
		if i%4==0:
			if i%100==0:
				if i%400==0:
					#print(i,end=",")
					y_lp.append(i)
			else:
				#print(i,end=",")
				y_lp.append(i)
	#print("\n")
	return y_lp
	
n1=int(input("Enter lower limit:"))
n2=int(input("Enter upper limit:"))

print(leapyear(n1,n2))
