# 4.program to display Powers of 2  using Anonymous functions?(lambda,map)


p_list=list(map(lambda x:2**x,[i for i in range(1,9)]))


print(p_list)

