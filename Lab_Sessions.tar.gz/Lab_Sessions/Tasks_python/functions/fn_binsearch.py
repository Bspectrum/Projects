#6 program to implement binary search algorithm

def binsearch(chk_list,chk_item):
	start=0
	end=len(chk_list)-1
	mid=int( (start+ end)/2)
		#mid=int( (start+ (end-start))/2  )
	found=False
	while start<=end and not found:
		mid=int( (start+ end)/2)
		if chk_list[mid]==chk_item:
			return mid		
		elif chk_list[mid]>chk_item:
			end=mid-1
			#return binsearch(chk_list,chk_item,start,end)
		else:
			start=mid+1
			#return binsearch(chk_list,chk_item,start,end)
		




srch_list=[1,2,3,4,5]
print(srch_list)
item=int(input("Enter search item:"))

print("%d found at " %(item))

print(binsearch(srch_list,item))
