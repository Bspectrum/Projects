#3.program to take a string as input and return a string with vowels removed.(implement List Comprehesion)

def rem_punct(chk_str):
	c_str="aeiouAEIOU"
	res=""	
	"Remove punctuations using function implementing list comprehension"
	res=res.join([i for i in chk_str if i not in c_str])
	
		
	return res

val=input("Enter a string:")

print(rem_punct(val))
