#9 Factorial using recursion

def fact(n):
	"Returns factorial of a number using recursion"
	if n==1:
		return 1
	else:
		return n*fact(n-1)

n=int(input("Enter a value for factorial:"))
print("Factorial of %d = %d" %(n,fact(n)))
