#5 program to implement bubble-sort algorithm

def bubblesort(chk_list):
	"Perform bubble sort"
	for i in range(0,len(chk_list)):
		for j in range(i+1,len(chk_list)):
			if chk_list[i]>chk_list[j]:
				temp=chk_list[i]
				chk_list[i]=chk_list[j]
				chk_list[j]=temp
	return chk_list


q_list=[]
n=int(input("Enter number of elemenets:"))
print("Enter values to list:")
for i in range(0,n):
	l_val=int(input(""))
	q_list.append(l_val)

print(bubblesort(q_list))

