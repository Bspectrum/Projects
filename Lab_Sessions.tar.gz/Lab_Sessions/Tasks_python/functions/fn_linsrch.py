#Function to perform linear search

def linsrch(v_list,item):
	for i in range(0,len(v_list)):	
		if v_list[i]==item:
			print("%d found at %d th position" %(item, i+1))
			break
	else:
		print("Not found")


n=int(input("Enter list length:"))

print("Enter list:") 
v_list=[]
for i in range(0,n):
	lval=int(input(""))
	v_list.append(lval)

print(v_list)
item=int(input("Enter search item:"))
linsrch(v_list,item)

