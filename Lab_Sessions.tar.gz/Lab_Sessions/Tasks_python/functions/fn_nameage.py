#function to display name and age

def disp_keyword(name,id1):
	print("Name:",name)
	print("id:",id1)
	return

#name=input("Enter name:")
#age=int(input("Enter age:"))


disp_keyword(id1=123,name='abc1')
print("------------------------------")

def disp_required(name,id1):
	print("Name:",name)
	print("id:",id1)
	return

disp_required('abc2',2345)

print("------------------------------")

def disp_default(name='abc3',id1=345):
	print("Name:",name)
	print("id:",id1)
	return

disp_default()
print("------------------------------")
