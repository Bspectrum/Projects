def list_square(n_list):
	"To input corresponding square values into another list"
	print("Inside square function")
	sq_list=[]
	for i in n_list:
		sq_list.append(i*i)
	#print(sq_list)	
	return sq_list

def list_cube(n_list):
	"To input corresponding cube values into another list"
	cu_list=[]
	for i in n_list:
		cu_list.append(i**3)
	print(cu_list)
	return cu_list


#n=int(input("Enter list length:"))
#n_list=[]
#print("Enter list:")
#for i in range(0,n):
	#l_val=int(input(""))
	#n_list.append(l_val)

#print(n_list)
n_list = range(0,10)
square_list=list_square(n_list)
print(square_list)

cube_list=list_cube(n_list)
print(cube_list)


