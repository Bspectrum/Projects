#program to remove all punctuations from given string

def rem_punct(chk_str):
	"Removes punctuations from a string"
	c_str="~!@#$%^&*()_+`-=[]{};':,./<>?"
	r_str=""
	for i in chk_str:
		if i not in c_str:
			r_str+=i
	print("String after removing punctuations:")	
	print(r_str)


q_str=input("Enter a string to remove punctuations:")

rem_punct(q_str)
