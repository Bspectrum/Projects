def swap1(a,b):
	"To swap two numbers"
	temp=a
	a=b
	b=temp
	return a,b
	
x=int(input("Enter x:"))
y=int(input("Enter y:"))

print("before swapping:")
print("x=",x)
print("y=",y)

swap1(x,y)

print(swap1(x,y))

print("After swapping")

print("x=",x)
print("y=",y)


