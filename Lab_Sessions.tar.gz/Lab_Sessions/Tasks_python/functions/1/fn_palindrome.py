# program to Check if the given string  is Palindrome or not

def palindrome(chk_str):
	"To check whether the given string is palindrome or not"
	rev_str=chk_str[::-1]
	if chk_str==rev_str:
		print("Palindrome")
	else:
		print("Not palindrome")
	return True


w_str=input("Enter a string:")

palindrome(w_str)

