#Program to Display Multiplication Table

def m_table(n):
	"Multiplication Table"
	for i in range(1,21):
		print("%d * %d = %d" %(i,n,(i*n)))

n=int(input("Enter a number to print multiplication table:"))

m_table(n)
