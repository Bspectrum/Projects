def append_list(list1,val1):
	list1.append(val1)
	return list1	


list1=[2,5]
print(list1)

x=int(input("Enter a value:"))

print(append_list(list1,x))
#print(list1)



	
