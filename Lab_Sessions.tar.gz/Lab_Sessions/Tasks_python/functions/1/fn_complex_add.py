#To perform addition in complex numbers

def add_complex(c1,c2):
	"To add two complex numbers"
	res=c1+c2
	return res

c1=complex(input("Enter complex number 1:"))
c2=complex(input("Enter complex number 2:"))
print(c1,"      +")
print(c2)
print("-------------")
print(add_complex(c1,c2))

