#To print a * pattern

def pattern1():
	"To print a pattern"
	for i in range(6,0,-1):
		for j in range(i,0,-1):
			print("*",end="")
		print("\n")
	return True


pattern1()
