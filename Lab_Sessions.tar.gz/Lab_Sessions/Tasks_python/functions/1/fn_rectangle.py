#program to calculate the area and perimeter of a rectangle

def rect(l,b):
	"Area and perimetre of rectangle"
	print("Area=",(l*b))
	print("Perimetre=",(2*(l+b)))


l=int(input("Enter length:"))
b=int(input("Enter breadth:"))

rect(l,b)
