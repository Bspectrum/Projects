#program to find the factorial of the given number.

def fact(n):
	"To print factorial"
	if n==1:
		return 1
	else:
		return (n*fact(n-1))


n=int(input("Enter a number:"))
print("Factorial of %d = %d" %(n,fact(5)))
