#Check a given number is odd or even using function

def odd_even(n):
	"To check whether a number is even or odd"
	if n%2==0:
		print("Even")
	else:
		print("Odd")
	return True


x=int(input("Enter a number:"))

odd_even(x)
