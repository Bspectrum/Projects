#leap year

def check_ly(year):
	if year%4==0:
		if year%100==0:
			if year%400==0:
				print("It is a leap year")
			else:
				print("Not a leap year")
		else:
			print("is a leap year")
	else:
		print("Not a leap year")
		
	return True
		
y=int(input("Enter a year:"))
check_ly(y)

			
