#program for Printing Odd numbers between 1 and 50 and calculate the sum of that numbers

def odd_sum():
	"To print sum of odd numbers between 1 and 50"
	o_sum=0
	for i in range(1,50):
		if i%2!=0:
			o_sum+=i

	print("Sum=",o_sum)
	return True

odd_sum()
