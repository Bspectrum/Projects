#program to find sum of all integers greater than 100 and less than 200 that are divisible by 7

def div7():
	"Display sum of integers divisible by 7 between 100 and 200"
	n_sum=0
	for i in range(100,200):
		if i%7==0:
			n_sum+=i
	print("Sum:",n_sum)

div7()	
