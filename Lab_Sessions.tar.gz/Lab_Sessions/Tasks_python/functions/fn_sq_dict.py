#2.program to define a function which can print a dictionary where the keys are numbers between 1 and 20 (both included) and the values are square of keys

def sq_dict():
	"Print a dictionary, key:value(square_of_key)"
	v_dict={}
	for i in range(1,21):
		v_dict[i]=i**2
	return v_dict


print(sq_dict())

