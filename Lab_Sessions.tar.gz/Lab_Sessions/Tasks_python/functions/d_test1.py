
def calc(fnsq):
	def inner(n):
		print("The cube of the number is :")
		return fnsq(n)
	return inner	
			

	


@calc
def fnsquare(n):
	return n**2



print(fnsquare(2))

