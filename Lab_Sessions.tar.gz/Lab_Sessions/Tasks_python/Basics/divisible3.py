print("Divisibility by 3..")

num=int(input("Enter a number to check:"))

if num%3==0:
	print("Number is divisible by 3")
else:
	print("Number is not divisible by 3")


