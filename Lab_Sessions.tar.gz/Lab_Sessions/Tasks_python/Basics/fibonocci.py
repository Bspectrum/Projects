#A program to print the fibonocci series

i=0
j=1
temp=0
lim=int(input("Enter the upper limit for the fibonocci series:"))
print(i,j,end=" ")
for j in range(j,lim-2):
	temp=i+j
	print(temp,end=" ")
	i=j	
	j=temp
	
	
