print("Enter a number to check whether it's positive or not:")

num=int(input("Enter a number:"))
if num>0:
    print("Number is zero")

else:
    print("Number is not positive. ie, is either zero or negative.")


