str1=input("Enter a string")
ss2=input("Enter a substring to check:")

if ss2 in str1:
	print("Yes")
else:
	print("No")

