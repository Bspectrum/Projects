print("Arithmetic operations for a=13,b=2 for python3")

a=13
b=2

print("Sum =",a+b)
print("a-b=",a-b);
print("b-a=",b-a);
print("a*b=",a*b);
print("a/b=",a/b);
print("a//b=",a//b);
print("a^b=",a**b);
