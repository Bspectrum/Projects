#to check whether a number is positive or negative
print("Program to check whether a number is positive or negative..")

num=int(input("Enter a number:"))

if num>=0:
	if num==0:
		print("Number is zero..")
	else:
		print("Number is positive..")
else:
	print("Number is negative..")

