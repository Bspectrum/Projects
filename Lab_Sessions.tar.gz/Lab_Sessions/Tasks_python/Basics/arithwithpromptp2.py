print Arithmetic operations in Python2 with prompt

a=input("Enter value for a:")
b=input("Enter value for b:")

print "a+b=",a+b
print "a-b=",a-b
print a*b
print a/b
print a%b
print a**b
print a//b

