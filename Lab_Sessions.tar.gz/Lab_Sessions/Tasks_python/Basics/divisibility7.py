print("Divisibility of 7..")

num=int(input("Enter a number to check its divisibility by 7: "))

if num%7==0:
	print("Divisible by 7")
else:
	print("Not divisible by 7")

