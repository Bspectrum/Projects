#Program to check a number is even or odd
print("To check whether the given number is Even or Odd..")

num=int(input("Enter a number to check:"))

if num%2==0:
	print("Number is even.")
else:
	print("Number is odd.")
