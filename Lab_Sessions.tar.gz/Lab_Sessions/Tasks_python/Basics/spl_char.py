#Program to remove special charectors in a string

chk_str=input("Enter the string:")
res_str=""
chk_sp="~!@#$%^&*()_+`=-\][';./,?><:{}|"
for i in chk_str:
	if i not in chk_sp:
		res_str+=i
	
	
print(chk_str)
print(res_str)
