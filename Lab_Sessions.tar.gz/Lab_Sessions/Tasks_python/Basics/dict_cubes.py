#Program to create a dictionary with the keys as numbers and corresponding squares as their values

n=int(input("Enter the limit:"))

cube_dict={}

for i in range(1,(n+1)):
	cube_dict[i]=(i**3)

print(cube_dict)
