#read some numbers seperate the odd and even numbers into seperate lists using list comprehension

n=int(input("Enter number of elements:"))
l_list=[]

print("Enter elements:")
for i in range(0,n):
	l_val=int(input(""))
	l_list.append(l_val)



odd_list=[i for i in l_list if i%2!=0]

even_list=[i for i in l_list if i%2==0]

print("Odd numbers :",odd_list)
print("Even numbers:",even_list)
	
