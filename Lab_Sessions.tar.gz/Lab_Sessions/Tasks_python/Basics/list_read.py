#read into list

n=int(input("Enter number of elements in the list:"))
list1=[]
for i in range(0,n):
	a=int(input(""))
	list1.append(a)

print(list1)
