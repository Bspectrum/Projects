#to list the even numbers using range, for loop

print("To print even numbers in between..")
ll=int(input("Enter lower limit:"))
ul=int(input("Enter upper limit:"))

for i in range(ll,(ul+1)):
	if i%2==0:
		print(i)
