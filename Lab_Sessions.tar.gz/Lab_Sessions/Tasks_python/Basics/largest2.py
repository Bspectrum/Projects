print("To find the largest number among two numbers..")

num1=int(input("Enter number 1:"))
num2=int(input("Enter number 2:"))

if num1>num2:
	print("%d is larger than %d" %(num1,num2))
elif num1==num2:
	print("%d=%d.. Both are equal" %(num1,num2))
else:
	print("%d is larger than %d" %(num2,num1))
