#to check whether the person is major or minor
print("To check whether the person is major or minor")
uname=input("Enter name: ")
uage=int(input("Enter age: "))

if uage>=18:
	print("%s is major" %(uname))
else:
	print("Person is minor" %(uname))

