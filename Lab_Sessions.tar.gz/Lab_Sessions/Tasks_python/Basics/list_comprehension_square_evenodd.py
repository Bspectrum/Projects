#get the squares of even and odd numbers in an interval in seperate lists

ll=int(input("Enter the lower limit:"))
ul=int(input("Enter the upper limit:"))

l_list=[i for i in range((ll+1),ul)]

even_sq_list=[i**2 for i in l_list if i%2==0]

odd_sq_list=[i**2 for i in l_list if i%2!=0]

print("Squares of odd numbers :",odd_sq_list)
print("Squares of even numbers :",even_sq_list)
