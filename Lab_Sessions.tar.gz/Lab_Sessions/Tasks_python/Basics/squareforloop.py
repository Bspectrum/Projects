#Printing square of a range of numbers using range and for loop

print("Program to print square of numbers using for loop..")
ul=int(input("Enter the upper limit:"))
print("Squares:")
for i in range(1,(ul+1)):
	print("%d ^ 2 = %d" %(i,(i**2)))
