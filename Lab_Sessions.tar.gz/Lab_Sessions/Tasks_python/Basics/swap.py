#swap two variables
print("Swap two numbers :")

num1=int(input("Enter number1 :"))
num2=int(input("Enter number2 :"))
print("Numbers before swapping: ")
print("Num1= %d,  num3= %d" %(num1,num2))
temp=0

temp=num1
num1=num2
num2=temp

print("num1 = %d" %(num1))
print("num2 = %d" %(num2))

