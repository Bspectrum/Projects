name='Kishor'
age=22

def details(name,age):
	print("Name",name)
	print("Age:",age)

details(name,age)
