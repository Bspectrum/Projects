def display_name(name):
	"This fumction prints a message"
	print("My name is %s"%(name))



name=input("Enter name : ")

display_name(name)
