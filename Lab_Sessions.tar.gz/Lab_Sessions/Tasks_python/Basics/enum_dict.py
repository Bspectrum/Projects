v_dict={'v_name':'Vento','v_brand':'Volkswagon','v_price':1500000}

print(v_dict)
for i in enumerate(v_dict):
	print(i)

print("__________________________________")

for i,val in enumerate(v_dict.items()):
	print(i,val)

print("________________________________________")

for i,val in v_dict.items():
	print(i,val)
