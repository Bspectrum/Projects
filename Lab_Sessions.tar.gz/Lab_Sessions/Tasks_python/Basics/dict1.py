#dictionary

dict1={'id':1671,'Name':'kishor','loc':'Thodupuzha'}

print(dict1)
