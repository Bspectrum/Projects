#list the vowels in the word "MATHEMATICS" in a seperate list

w_str="MATHEMATICS"
r_list=[]

for i in w_str:
	if i in ['a','e','i','o','u','A','E','I','O','U']:	
		r_list.append(i)

print(r_list)
