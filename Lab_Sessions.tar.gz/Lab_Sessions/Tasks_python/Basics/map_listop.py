#operations on list using map, list and lambda
n=int(input("Enter number of elements for list:"))

list1=[]
list2=[]
print("Enter list 1:")


for i in range(0,n):
	l_val=int(input(""))
	list1.append(l_val)

print("Enter list2:")

for i in range(0,n):
	l_val=int(input(""))
	list2.append(l_val)

#operations
print(list1)
print(list2)
l_sum=list(map(lambda x,y:x+y,list1,list2))
print("____________________________________")
print("sum ")
print(l_sum)
print("____________________________________")
l_diff=list(map(lambda x,y:x-y,list1,list2))
print("Difference")
print(l_diff)
print("____________________________________")
l_mult=list(map(lambda x,y:x*y,list1,list2))
print("Product")
print(l_mult)
print("____________________________________")
l_div=list(map(lambda x,y:x/y,list1,list2))
print("Division")
print(l_div)
print("____________________________________")
l_floor=list(map(lambda x,y:x//y,list1,list2))
print("Floor division")
print(l_floor)

