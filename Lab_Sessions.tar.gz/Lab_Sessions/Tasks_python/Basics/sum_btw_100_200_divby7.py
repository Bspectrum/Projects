#A program to find sum of all integers greater than 100 and less than 200 that are divisible by 7
print(" program to find sum of all integers greater than 100 and less than 200 that are divisible by 7")

nsum=0
for i in range(101,201):
	if i%7==0:
		nsum+=i
		print(i,end="+")
print("=%d" %(nsum))
