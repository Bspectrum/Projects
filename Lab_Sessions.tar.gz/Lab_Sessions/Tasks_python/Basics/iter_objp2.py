list2=['abc', 'cnn', 'bbc', 'fox', 'arirang']
list2_iter=iter(list2)
for i in range(0,(len(list2)+1)):
	print list2_iter.next()

