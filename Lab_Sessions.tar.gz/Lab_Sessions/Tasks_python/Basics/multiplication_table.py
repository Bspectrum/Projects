#Program to Display Multiplication Table
num=int(input("Enter a number to display multiplication table."))
for i in range(1,21):
	print("%d * %d = %d" %(num,i,(num*i)))
