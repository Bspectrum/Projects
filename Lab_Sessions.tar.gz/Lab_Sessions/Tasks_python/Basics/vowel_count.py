#a program to count the no:of each vowel in a given string.
count=0
chkstr=input("Enter a string:")
chkstr.lower()

for i in range(0,len(chkstr)):
	if(chkstr[i]=='a' or chkstr[i]=='e' or chkstr[i]=='i' or chkstr[i]=='o' or chkstr[i]=='u')
		count+=1

