def calc(a,b):
	"this fun adds two numbers"
	sum =a+b
	pdt = a*b
	print(pdt)
	return sum

a=int(input("Enter a:"))
b=int(input("Enter b:"))
result = calc(a,b)
print("Sum is %d",result)
