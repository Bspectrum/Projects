#to print a pattern a 12345(*)

ul=5

for i in range(5,0,-1):
	for j in range(0,i):
		print(" %d" %(i), end="")
	print("\n")		
