x=12

def funct1():
	"Scope of variable"
	x=25
	print("Inside fn, val of x is %d" %(x))
	

	
funct1()


print("outside fn, val of x :",x)

