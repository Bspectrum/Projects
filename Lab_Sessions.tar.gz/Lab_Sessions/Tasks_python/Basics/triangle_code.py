#to print a pattern
#    1
#   121
#  12421
# 1248121
#1248168421
k=-1
#printing * 
for i in range(7,0,-1):
	for j in range(i,1,-1):
		print(" ",end=" ")
	
#printing value	
	for l in range(0,k+1):
		print((2**l),end=" ")	
	
	
	for n in range(k+1,-1,-1):
		print((2**n),end=" ")
	
	
	k+=1
		

	
	
#printing *
	
	for p in range(i,1,-1):
		print(" ",end=" ")
	
	print("\n")
	
	
