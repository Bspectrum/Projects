#program to print a triangle
#___*___ 3 space * 3 space
#__*_*__ 2 space * 1 space * 2 space 
#_*___*_ 1 space * 3 space * 1 space
#*_____* 0 space * 5 space * 0 space


for i in range(3,-1,-1):
	for j in range(0,3):
		print(" ",j,end=" ")
	print(" *")
	print("\n")
	
	 
	
