num1 = 10
num2 = 30

result =num1+num2

print "RESULT",result
