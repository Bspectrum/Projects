#cube of a given number

n_cube=lambda x:x**3 

n=int(input("Enter a number:"))

print("%d ^ 3 = %d " %(n,n_cube(n)))
