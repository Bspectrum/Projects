#To check a number is prime or not

num=int(input("Enter a number :"))
count=0
for i in range(2,int(((num/2)+1))):
	if num%i==0:
		count+=1
	if count!=0:
		break

if count!=0:
	print("%d is not a prime number" %(num))
else:
	print("%d is a prime number" %(num))
