#to print numbers below a limit and print its sum using while

num=int(input("Enter limit:"))
nsum=0
temp=num
while temp>0:
	nsum+=temp
	print(temp,end="+")
	temp-=1
print("=",nsum)

