#To print a pattern 1234554321(*)

for i in range(1,11):
	if i<=5:
		for j in range(0,i):
			print("*",end=" ")
		print("\n")
	else:
		for j in range((10-i),-1,-1):
			print("*",end=" ")
		print("\n")

