
a=complex(input("Enter complex number 1:"))
b=complex(input("Enter complex number 2:"))



print(i)
