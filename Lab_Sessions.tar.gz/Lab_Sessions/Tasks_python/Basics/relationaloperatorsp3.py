a=10
b=21
print("a=",a,"b=",b)
print("a>b=",a>b)
print("a<b=",a<b)
print("a<=b=",a<=b)
print("a>=b=",a>=b)
print("a!=b=",a!=b)


