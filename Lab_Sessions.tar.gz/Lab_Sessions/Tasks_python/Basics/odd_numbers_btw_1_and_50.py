#to print the odd numbers in between 1 and 50 and print the sum of the odd numbers in between as well.

oddsum=0
for i in range(1,50):
	if i %2!=0:
		
		print("%d" %(i),end=" ")
		str1+=i
		oddsum+=i


print("\nSum of odd numbers is : %d" %(oddsum))
		
