#program to insert values into dictionary, where keys are natural numbers to a limit and the values are their corresponding squares

n=int(input("Enter the limit:"))
sq_dict={}


for i in range(1,(n+1)):
	sq_dict[i]=(i**2)

print(sq_dict)
