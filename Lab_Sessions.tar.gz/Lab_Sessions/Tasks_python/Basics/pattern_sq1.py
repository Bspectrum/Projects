#To print a pattern 
#1
#21
#421
#8421

for i in range(0,5):
	for j in range(i,-1,-1):
		print(2**j, end=" ")
	print("\n")
