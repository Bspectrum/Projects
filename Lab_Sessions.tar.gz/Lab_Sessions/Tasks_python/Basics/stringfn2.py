
str4=input("enter a new string:")

print(str4*3)



