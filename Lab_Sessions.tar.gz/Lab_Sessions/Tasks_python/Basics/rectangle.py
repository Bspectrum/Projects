#to calculate the area and perimetre of a rectangle
print("To calculate the area and perimetre of a rectangle..")

rlen=float(input("Enter the length:"))
rbr=float(input("Enter the breadth:"))

pr=2*(rlen+rbr)
ar=rbr*rlen

print("Area : %f" %(ar))
print("Perimeter : %f" %(pr))
