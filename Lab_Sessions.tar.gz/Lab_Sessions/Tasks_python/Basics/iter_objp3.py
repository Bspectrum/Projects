#program ends in:
#Traceback (most recent call last):
#  File "iterable_object.py", line 4, in <module>
#    print(list2_iter.__next__())
#StopIteration



list2=['abc', 'cnn', 'bbc', 'fox', 'arirang']
list2_iter=iter(list2)
for i in range(0,(len(list2)+1)):
	val=list2_iter.__next__()
	print(val)


		
