#Write a Python program to check that a string contains only a certain set of characters

#test_string  = "ABCDEFabcdef123450"
#test_string = "*&%@#!}{"

import re

def is_allowed_specific_char(string):
    charRe = re.compile(r'[^a-zA-Z0-9.]')
    string = charRe.search(string)
    return not bool(string)

test_string = input("Enter the string:")



if is_allowed_specific_char(test_string):
	print("Entered string is valid")
else: 
	print("Not a valid string!!!!!!!")
