# Write a python program that matches a string only contain 0-9 as the characters 
# and it must be at least 1 char in length and no more than 6


import re

str = input("Enter the string:")
pattern  = '^[0-9]{1,6}$'
if re.match(pattern,str):
	print("valid")
else:
	print("not valid")
