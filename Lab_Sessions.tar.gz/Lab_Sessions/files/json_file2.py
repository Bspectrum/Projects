import json

file_obj = open("json.txt","w")


#x = [1, 'simple', 'list']

limit = int(input("enter limit:"))
mylist = []
for i in range(1,limit):
	item = int(input("hjhj:"))
	mylist.append(item)

json.dump(mylist, file_obj)
file_obj.close()


file_obj1 = open("json.txt","r")

print(json.load(file_obj1))

file_obj1.close()


