obj = open("sample1.txt","w")

obj.write("Spectrum \n Softtech ")

obj.close()


seq = ["This is 6th line\n", "This is 7th line"]

obj2 = open("sample2.txt","w")
obj2.writelines(seq)
obj2.close()

