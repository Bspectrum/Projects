#use map to implement lambda function in python 2

list1=[]
list2=[]

n=int(input("Enter list length:"))
print("Enter first list:")
for i in range(0,n):
	l_val=int(input(""))
	list1.append(l_val)
print("Enter second list:")

for i in range(0,n):
	l_val=int(input(""))
	list2.append(l_val)

print("Arithmetic operations on lists:")
print(list1)
print(list2)

print("________________________________________________________")
print("List1 + list 2 = ")
res=list(map(lambda x,y:x+y,list1,list2))
print(res)
print("________________________________________________________")


print("List1 - list 2 = ")
res=list(map(lambda x,y:x-y,list1,list2))
print(res)
print("________________________________________________________")


print("List1 * list 2 = ")
res=list(map(lambda x,y:x*y,list1,list2))
print(res)


print("________________________________________________________")
print("List1 / list 2 = ")
res=list(map(lambda x,y:x/y,list1,list2))
print(res)
print("________________________________________________________")


print("List1 // list 2 = ")
res=list(map(lambda x,y:x//y,list1,list2))
print(res)

print("________________________________________________________")
print("List1 mod list 2 = ")

res=list(map(lambda x,y:x//y,list1,list2))
print(res)


