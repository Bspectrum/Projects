
from functools import reduce
list1 = [1,34,5,6,5]

output = reduce(lambda x,y:x+y,list1)

print("Applied reduce()",output)

