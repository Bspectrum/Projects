

a= int(input("ente rthe real part of first CN"))
b = int(input("enter imaginary of first CN"))
x = int(input("enter the real part of first CN"))
y = int(input("enter imaginary of first CN"))

cn1=complex(a,b)
cn2=complex(x,y)
print(cn1, type(cn1))
print(cn2, type(cn2))
#print("Division of two complex numbers : ",a+b)
