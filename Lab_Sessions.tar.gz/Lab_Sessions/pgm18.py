lines = []
num = raw_input("Enter how many elements you want:")
for i in range(int(num)):
    s = raw_input("enter string")
    #num_array.append(int(n))
    if s:
        lines.append(s.upper())
    else:
        break;

for sentence in lines:
    print sentence
