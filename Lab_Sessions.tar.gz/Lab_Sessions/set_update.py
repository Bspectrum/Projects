my_set =  {1, 2, 3}
my_set.remove(3)
print(type(my_set))
print(my_set)
print(my_set.pop())
print(my_set,"PPPPPP")

color_set = set()
color_set.add("Red")
print(color_set,"ccccccccccc")
#Add multiple items
color_set.update(["Blue", "Green"])
print(color_set,"ddddddddddddddddddd")
