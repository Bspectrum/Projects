class Circle(object):
    def __init__(self, r):
        self.radius = r

    def area(self):
        return self.radius**2*3.14

rad = input("Enter the radius :")
aCircle = Circle(rad)
print "Area of the Circle :",aCircle.area()
