num = input("Enter the number need to be check: ")

if num>0:
	print "It is a positive nummber"
elif num==0:
	print "It is zero"
else:
	print "No: is negative"
