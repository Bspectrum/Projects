lines = []
num = raw_input("Enter how many elements you want:")
for i in range(int(num)):
    s = int(input("enter element"))
    lines.append(s)
print "Given List", lines
list2 = [x for x in lines if x%2!=0]

print "Resultant list with odd numbers",list2
