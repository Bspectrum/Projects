for i in range(1, 9):
    for i in range(-1+i, -1, -1):
        print(format(2**i, "4d")),
    print
