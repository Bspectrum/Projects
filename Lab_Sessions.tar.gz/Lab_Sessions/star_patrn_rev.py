x=int(input("enter range:"))
for i in range(x,0,-1):
	for j in range(i+1,1,-1):
		print("*",end=" ")
	print()

