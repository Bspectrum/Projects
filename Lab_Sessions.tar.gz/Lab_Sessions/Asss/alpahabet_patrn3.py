limit = int(input("Enter the value:"))
num=65
for i in range(1, limit+1):
    
    for j in range(0,i):
        print(chr(num),end=" ")
        num+=1
    print()
