class Human:
 
    def sayHello(self, name=None):
 
        if name is not None:
            print 'Hello ' + name
        else:
            print 'Hello '

    def sayHello(self, name=None,test=None):
	if name is not None and test is not None:
            print 'Hello ' + name + test
        else:
            print 'Hello '
# Create instance
obj = Human()
 
# Call the method
obj.sayHello()
 
# Call the method with a parameter
obj.sayHello('Guido')
# Call the method with 2 parameters
#obj.sayHello('Guido','yyyyy')
