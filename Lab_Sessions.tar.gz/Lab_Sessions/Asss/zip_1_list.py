list1 = [1,2,3]
list2 = [4,5,6]
new = []

for i,v in zip(list1,list2):
	new.append(i+v)

print(list1)
print(list2)

print(new)

