class Complex:
	def __init__(self, real, img):
		self.real  =real
		self.img = img

	def display(self, real, img):
		print(real)
		print(img)

comp = Complex(3,5)

print(comp.real)
print(comp.img)
