
x = int(input("Enter the number:"))

y = int(input("Enter the second num:"))

sum = lambda x,y:x+y

print(sum(x,y))
