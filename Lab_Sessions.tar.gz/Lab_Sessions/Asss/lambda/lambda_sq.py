fun = lambda x:x*x

print(fun(9))
