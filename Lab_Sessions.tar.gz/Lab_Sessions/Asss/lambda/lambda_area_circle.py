
#WAP to calculate the area of circle using lambda function


x = int(input("Enter the radius:"))

area = lambda x:3.14*x*x

print(area(x))
