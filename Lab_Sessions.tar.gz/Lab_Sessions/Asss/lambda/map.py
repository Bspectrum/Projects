list1 = [1,2,3,4]

output  =map(lambda x:x**2,list1)

print("MAP",list(output))

print("__________________________________")

res  = list(filter(lambda x:x%2,list1))

print("filter",res)

print ("______________________________________________")





