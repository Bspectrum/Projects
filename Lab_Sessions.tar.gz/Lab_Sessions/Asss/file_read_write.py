
# write data to a new file
a=100
print(a)
file_obj = open("file_opertn.txt","w")

file_obj.write("I am a test file.\nMaybe someday, he will promote me to a real file.\nMan, I long to be a real file \nand hang out with all my new real file friends.")

file_obj.write("%d" %(a))

file_obj = open("file_opertn.txt","r")

for line in file_obj:
   print(line, "******")


print ("###",file_obj.tell())

#print("First read()", file_obj.read())

#print("Second read(3)",file_obj.read(4))

#print("First readline()", file_obj.readline())

#print("Second readline()", file_obj.readlines())

#print("THIRD readline()", file_obj.readline(6))

file_obj.close()


