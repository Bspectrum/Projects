class Test:
	
	def __init__(self):
		print("test constructr")

	def show(self,x):
		print(x)

	def show(self):
		print("tttttttttt")


t = Test()

t.show(10)
t.show()

