
sum= 0
for i in range(1,51,2):
	sum = sum+i
print sum

