
from abc import ABCMeta, abstractmethod

class Animal:
    __metaclass__ = ABCMeta

    @abstractmethod
    def say_something(self):
	return "hi"

class Cat(Animal):
    def say_something(self):
        return "Miauuu!"

#a= Animal()    //can't create object
c = Cat()
x = c.say_something()
print x
