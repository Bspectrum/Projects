punct = '*#$'

str1 = 'hel*lo world 123*#'

no_punt = ''

for char in str1:
	if char not in punct:
		no_punt = no_punt+char

print(no_punt)