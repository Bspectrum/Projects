class Shape(object):
    def __init__(self):
        pass

    def area(self):
        return 0

class Square(Shape):
    def __init__(self, l):
        Shape.__init__(self)
        self.length = l

    def area(self):
        return self.length*self.length

side = input("enter the side for square:")
aSquare= Square(side)
print "Area of square:", aSquare.area()
