num=input("Enter the number need to be check: ");

if num%2==0:
	print "It is an Even number"
else:
	print "It is an Odd number" 
