num2 = [1,2,3,4]
str = "foo"
new = []
for i in num2:
	
	new.append(i+str)

#s + mystring for s in mylist
#print(['emp{0}'.format(i) for i in  num])

num1 = [7,8, 120, 25, 44, 20, 27]
print(num1)
num3 = []
for x in num1:
	if x%2!=0:
		num3.append(x)
#num = [x for x in num if x%2!=0]
print(num3)
