
x= int(input("enter the range for pattern"))
start = 2
for i in range(0,x):
	for j in range(i+1):
		print(start,end=" ")
		start+=2
	print()

