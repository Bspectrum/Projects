def reverse(text):
    a = ""
    for i in range(1, len(text) + 1):
        a += text[len(text) - i]
    return a

print(reverse("Hello World")) 


mystr = input("enter the string:")

rev_str = ''

for i in range(1,len(mystr)+1):
	rev_str += mystr[len(mystr)-i]
print(rev_str)
