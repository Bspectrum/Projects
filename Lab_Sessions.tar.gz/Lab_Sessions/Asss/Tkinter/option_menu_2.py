from tkinter import *

master = Tk()
master.geometry("500x500")
var = StringVar(master)
var.set("one") # initial value

option = OptionMenu(master, var, "one", "two", "three", "four")
option.pack()

#
# test stuff

def ok():
    print("value is", var.get())
    label_obj = Label(master,text ="value is %s" %(var.get()))
    label_obj.pack()
    #master.quit()

button = Button(master, text="OK", command=ok)
button.pack()

mainloop()
