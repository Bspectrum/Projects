from tkinter import *

master = Tk(className="Canvas - Widget")

master.geometry("500x500")
my_canvas = Canvas(master, width=200, height=100)
my_canvas.pack() 

my_canvas.create_line(0, 0, 200, 100)
my_canvas.create_line(0, 100, 200, 0, fill="red", dash=(4, 4))

#my_canvas.create_rectangle(50, 25, 150, 75, fill="blue")

# item = my_canvas.create_line(0, 0, 100, 100, tags="uno")
# my_canvas.itemconfig(item, tags=("one", "two"))
# my_canvas.addtag_withtag("three", "one")
# print(my_canvas.gettags(item))

master.mainloop()
