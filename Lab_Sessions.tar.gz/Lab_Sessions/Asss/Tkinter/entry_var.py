from tkinter import *

root = Tk(className="My first GUI") 
root.geometry("500x500")
str1 = StringVar()
str1.set("Emerald")
e = Entry(root,textvariable=str1).pack()
x = IntVar()
x.set(10)
Lbl = Label(root, textvariable=x,bd=10,relief=SUNKEN).pack()

root.mainloop() 
