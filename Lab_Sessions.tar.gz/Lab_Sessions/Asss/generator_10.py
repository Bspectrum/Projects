def NumGenerator(n):
    for i in range(n+1):
        if i%5==0 and i%7==0:
            yield i

n=input("enter limit: ")
values = []
for i in NumGenerator(n):
    values.append(str(i))

print ",".join(values)
