import re
if re.match(r'^[\d]',str):
	print(str.strip())
else:
	print("noooooooo")
