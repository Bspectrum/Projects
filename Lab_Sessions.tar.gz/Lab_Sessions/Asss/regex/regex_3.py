#Write a Python program to find sequences of lowercase letters joined with a underscore.
import re
def text_match(text):
        patterns = '^[a-z]+_[a-z]+$'
        if re.search(patterns,  text):
                return 'Found a match!'
        else:
                return('Not matched!')

print("full lowercase:",text_match("aab_cbbbc"))
print("full uppercase:",text_match("AAA_ACVCVC"))
print("full lower_uppercase:",text_match("aab_acca"))
print("full upper_lowercase:",text_match("z_dfsd"))
