#Write a regular expression which matches strings which starts with a sequence of digits - at least one digit - followed by a blank and after this arbitrary characters


import re

str = input("Enter the string")
if re.match(r'^[0-9]',str):
	print(str.strip())
else:
	print("noooooooo")
