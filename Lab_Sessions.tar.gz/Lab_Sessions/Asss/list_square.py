ll = int(input("enter the lower limit:"))
ul =int(input("enter the limit:"))
list_n = []
for i in range(1,ul+1):
   list_n.append(i**2)
print(list_n)


