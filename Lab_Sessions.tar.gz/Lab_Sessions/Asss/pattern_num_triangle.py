for i in range(1, 9):
    n = 34-(5*(i-1))+1
    print(" ")*n,
    for i in range(0,i,1):
        print(format(2**i, "4d")),
    for i in range(-1+i, -1, -1):
        print(format(2**i, "4d")),   
    print
