numberList = [1, 2, 3,4,5]
strList = ['one', 'two', 'three','four','five','six']

for i in zip(numberList,strList):
	print(i)

print("_____________________________________________________________")
coordinate = ['x', 'y', 'z']
value = [3, 4, 5, 0, 9]

result = zip(coordinate, value)
resultList = list(result)
print(resultList)

c, v =  zip(*resultList)
print('c =', c)
print('v =', v)
