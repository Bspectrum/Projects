class Student:
	div = 'A'
	def __init__(self,id,name):
		self.id = ""				
		self.name = ""

	def read_stud(self):
		self.s_id = input("enter id:")
		self.name = input("enter name:")
																			
	def display(self):
		print("ID", self.id)
		print("Name",self.name)

		#print("Division",self.div)


print(Student.div,"((((((((((((((((")
stud = Student(10,"bini")
print("&&&&&&&&&&&",stud.div)
stud.read_stud()
stud.display()
