from operator import add,lt,le

x = int(input("enter the first num "))

y = int(input("enter second num :"))

z = add(x,y)

print(le(x,y))

print("Sum is %d" %(z))
