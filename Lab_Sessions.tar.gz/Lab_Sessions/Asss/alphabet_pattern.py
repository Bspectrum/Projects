limit = int(input("Enter the value:"))
for i in range(1, limit+1):
    for j in range(65, 65+i):
        print(chr(j),end=" ")
    print()
