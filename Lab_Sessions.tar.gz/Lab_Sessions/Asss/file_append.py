import os
# write data to a new file

file_obj = open("file_opertn.txt","a")

for i in range(1,10):
    file_obj.write(str(i))

#os.remove("file_opertn.txt")
os.rename( "json.txt", "file_json.txt" )

file_obj.close()


