for i in range(7):
    print (str(i) + " ")*i

o/p:
1 
2 2 
3 3 3 
4 4 4 4 
5 5 5 5 5 
6 6 6 6 6 6 

for i in range(1, 8 + 1):
    for j in range(i, 0, -1):
        print(j),
    print("")
o/p:
1 
2 1 
3 2 1 
4 3 2 1 
5 4 3 2 1 
6 5 4 3 2 1 
7 6 5 4 3 2 1 
8 7 6 5 4 3 2 1 

for i in range(1, 9):
    for i in range(-1+i, -1, -1):
        print(format(2**i, "4d")),
    print

o/p:
   1
   2    1
   4    2    1
   8    4    2    1
  16    8    4    2    1
  32   16    8    4    2    1
  64   32   16    8    4    2    1
 128   64   32   16    8    4    2    1



for i in range(1, 9):
    for i in range(0,i,1):
        print(format(2**i, "4d")),
    for i in range(-1+i, -1, -1):
        print(format(2**i, "4d")),   
    print

o/p:

   1
   1    2    1
   1    2    4    2    1
   1    2    4    8    4    2    1
   1    2    4    8   16    8    4    2    1
   1    2    4    8   16   32   16    8    4    2    1
   1    2    4    8   16   32   64   32   16    8    4    2    1
   1    2    4    8   16   32   64  128   64   32   16    8    4    2    1

