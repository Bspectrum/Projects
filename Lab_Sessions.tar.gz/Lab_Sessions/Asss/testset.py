x= int(input("enter the limit:"))
my_set = set()

for i in range(1,x):
	item = int(input("enter the element:"))
	my_set.update(item)
print(my_set)
print("__________________________")


my_set1 = {12,3,4,56,57,7,87,9}

print(my_set1)

my_set1.discard(3)

print(my_set1)
