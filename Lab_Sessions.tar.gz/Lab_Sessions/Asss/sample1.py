xy=int(input("enter the name"))

print(xy)
