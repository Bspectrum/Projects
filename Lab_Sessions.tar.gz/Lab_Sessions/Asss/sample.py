x="ajomol andrews"
print(x)


n = int(input("Enter the limit:"))
my_list = []
for i in range(0,n):
   item = int(input("enter the value"))
   my_list.append(item)

print(my_list)
