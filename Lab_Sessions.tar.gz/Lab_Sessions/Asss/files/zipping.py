import tarfile
tar = tarfile.open("sample.tar.gz", "w:gz")
for name in ["test.py", "test_file.py"]:
    tar.add(name)
tar.close()
