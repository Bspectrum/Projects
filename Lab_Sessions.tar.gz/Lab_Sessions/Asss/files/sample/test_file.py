
fp = open("testfile.txt",'w')

my_str = 'specturm'

c = 'adsa,asdas,asd,asd,asd,sad,asdasd,asd,dasd'
fp.write(c)






fp.close()
