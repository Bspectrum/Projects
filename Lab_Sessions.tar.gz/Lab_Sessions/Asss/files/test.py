obj = open("test11.txt","w")

x = int(input("enter the number:"))

obj.write(x)

obj.close()
