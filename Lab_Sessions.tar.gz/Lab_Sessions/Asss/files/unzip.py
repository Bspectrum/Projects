
import gzip
f = gzip.open('test.tar.gz', 'rb')
file_content = f.read()
print(file_content)
f.close()


