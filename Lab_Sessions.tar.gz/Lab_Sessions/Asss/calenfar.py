import calendar


c = calendar.TextCalendar()

print(c.formatmonth(2017,10,1,1))
print("___________________________________")

# p = calendar.HTMLCalendar()

# print(p.formatmonth(2017, 10))
# print("___________________________________")


# print(calendar.month(2017, 10))

# print("___________________________________")


# print(calendar.calendar(2017))

# print("___________________________________")

# print(calendar.monthcalendar(2016,5))

print("___________________________________")

print(calendar.monthrange(2017,8))

print("____________________________________")

# cal= calendar.Calendar(firstweekday=0)
# for x in cal.iterweekdays():
# 	print(x)
print("____________________________________")

print(calendar.month_name[10])

for i in calendar.month_abbr:
	print(i)


for i in calendar.day_abbr:
	print(i)