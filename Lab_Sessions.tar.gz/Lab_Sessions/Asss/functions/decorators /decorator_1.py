def make_decor(fun):
	def inner_decor():
		print("Its get decorated to make")
		fun()
	return inner_decor

@make_decor
def test_fun():
    print("Its a normal ordinary function")


#decor = make_decor(test_fun)
#decor()
test_fun()


