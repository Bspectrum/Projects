def operate(func):
    def inner(x,y):
        print("decorating it")
        return func(x,y)
    return inner


@operate
def add(x,y):
    r = x+y
    return r

print(incr(10,10))

#def decr(x):
    #x=x-1
    #return x





#st = operate(decr)
#print(st(19))
