def smart_divide(func):
    def inner(a,b):
        print("I am going to divide",a,"and",b)
        if b == 0:
            print("Whoops! cannot divide")
            return
        return func(a,b)
    return inner

@smart_divide
def divide(a,b):
    print("DIvide.........")
    div = a/b
    #print("??????",div)
    return(div)

print(divide(10,0))
print(divide(10,5))

print("______________________________________________________")

def operate(func):
    def inner(x,y):
        print("decorating it")
        return func(x,y)
    return inner


@operate
def add(x,y):
    r = x+y
    return r

print(add(10,10))
