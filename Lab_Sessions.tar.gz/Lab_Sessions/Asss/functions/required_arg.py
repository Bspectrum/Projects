def display(str1,str2):
	print(str1)
	print(str2)

my_str = input("entr string:")

place = input("Enter place:")

display(my_str,place)
