def checkValue(n):
	if n%2 == 0:
		print "It is an even number"
	else:
		print "It is an odd number"
		
num = input("Enter the number to be checked: ")
checkValue(num)

