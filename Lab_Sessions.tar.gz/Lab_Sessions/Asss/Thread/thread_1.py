
from _thread import start_new_thread
from threading import Thread
from time import sleep
def print_d(a):
    """Calculates the square root of a"""
    #eps = 0.0000001
    #old = 1
    #new = 1
    #while True:
        #old,new = new, (new + a/new) / 2.0
        #print(old, new)
        #if abs(new - old) < eps:
            #break
    #return new
    print("HI",a)
    return a

if __name__ == "__main__":
	thread = Thread(target =print_d, args = (10, ))
	thread.start()
	thread.join()
	#start_new_thread(print_d,(99,))
	#start_new_thread(print_d,(999,))
	#start_new_thread(print_d,(1733,))

#c = input("Type something to quit.\n")
