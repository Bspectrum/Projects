
def decor1(fun):
	def inner(a,b):
		print("summmmmmmmmmm")
		fun(a,b)
	return inner


@decor1
def sum1(a,b):
	print(a+b)

sum1(10,20)
