import time

def timedecor(func):
	def inner_dec(x):
		start = time.time()
		func(x)
		end = time.time()
		print("Time taken:",str((end-start)*1000),"Milliseconds")

def calc_square(*numbers):
	#start = time.time()
	sqre_list = []
	for i in numbers:
		sqre_list.append(i*i)
	#end = time.time()
	#print("Time taken:",str((end-start)*1000),"Milliseconds")
	return sqre_list

def cal_cube(numbers):
	start = time.time()
	cube_list  = []
	for i in numbers:
		cube_list.append(i*i*i)
	end = time.time()
	print("Time taken:",str((end-start)*1000),"Milliseconds")
	return cube_list

array_num = range(1,10)
result_square = calc_square(1,2,3)
print("List of squares", result_square)

result_cube = cal_cube(array_num)
print("List of cubes", result_cube)
