def test_fun():
	print("It is a normal_ordinary function")


def make_decor(fun):
	def inner():
		print("It gets decorated here...")
		fun()
	return inner


test_fun()

decor = make_decor(test_fun)

decor()

print("____________________________________________________________________________")

def make_decor(fun):
	def inner():
		print("It gets decorated here...")
		fun()
	return inner

@make_decor
def test_fun():
	print("It is a normal_ordinary function")

test_fun()
