def printdict():
	r_dict = {}
	for i in range(1,20):
		r_dict[i] = i**2
	return r_dict

result  = printdict()
print "Resultant Dictionary" , result
