def display():
   "this prints a mesage"
   print("Hai all Welcome")

display()

print("_____________________________________________")

def display_name(name):
    "This accepts a parameter"
    print("My name is %s" %(name))

display_name("ajomol")

print("_____________________________________________")


def dislay_var_scope():
    "x is local variable"
    x=10
    print("inside the function %d" %(x))

x=70
dislay_var_scope()

print("OUTSIDE function:",x)



