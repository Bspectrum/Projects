num = 65
 
    # outer loop to handle number of rows
for i in range(0, 7):
    for j in range(65,65+1):
        ch = chr(j)
        print(ch, end=" ")
        num = num +1
    print("\r")
