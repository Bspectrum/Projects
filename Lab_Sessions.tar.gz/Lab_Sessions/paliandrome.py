#my_str = 'aIbohPhoBiA'

# make it suitable for caseless comparison
my_str = raw_input("Enter the string: ")
my_str = my_str.lower()

# reverse the string
rev_str = reversed(my_str)

# check if the string is equal to its reverse
if list(my_str) == list(rev_str):
   print("It is palindrome")
else:
   print("It is not palindrome")
